# s3-config-check
This python script checks the configuration on the deployed S3 buckets for MFA delete and Versioning.
Configure your AWS user credentials having access to the S3 buckets using AWS configure command.
Run the python script and an excel sheet will be created on same folder location with bucket config details like MFA delete, S3 versioning and recommendations.
